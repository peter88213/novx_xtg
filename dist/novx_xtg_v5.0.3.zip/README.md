[Project homepage](https://github.com/peter88213/novx_xtg) > Instructions for use

---

The novx_xtg Python script runs through all chapters and sections of a novelibre 7 project and fills XTG templates.

# Operation

See the [online help](https://peter88213.github.io/nvhelp-en/novx_xtg/).
